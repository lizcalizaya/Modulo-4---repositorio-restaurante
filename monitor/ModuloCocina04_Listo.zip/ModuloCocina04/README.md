# ModuloCocina04 (Django)

Estructura limpia con app `mainApp`, modelos `Mesa` y `Pedido` (pedido se guía por **mesa**, no por cliente).

## Requisitos
- Python 3.10+
- Virtualenv recomendado

## Instalación rápida

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
# source .venv/bin/activate

pip install -r requirements.txt
python manage.py migrate

# Crear un usuario admin (opcional)
python manage.py createsuperuser

# Datos de ejemplo (opcional)
python manage.py shell -c "from mainApp.models import Mesa; [Mesa.objects.get_or_create(numero=i) for i in range(1,6)]"

python manage.py runserver
```

- Abrir: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

## Endpoints clave
- `GET /` listado de pedidos + formulario
- `POST /pedidos/crear/` crea pedido (usa `mesa` y `detalle`)
- `POST /pedidos/<id>/estado/` cambia el estado (`EN_PREPARACION`, `LISTO`, `ENTREGADO`)

> Soporta también método tipo `PATCH` enviando `estado=EN_PREPARACION` en el body.

## Estructura
- `templates/` y `static/` a nivel de proyecto
- `media/` configurado
- `mainApp/` con `models`, `forms`, `views`, `urls`, `admin`
- `settings.py` con `TEMPLATES/STATIC/MEDIA` configurados y `LANGUAGE_CODE='es-cl'`, `TIME_ZONE='America/Santiago'`

## Notas
- Migra desde tu proyecto anterior copiando solo **datos válidos** y **plantillas** que necesites. Evita arrastrar incoherencias de admin/list_display.
