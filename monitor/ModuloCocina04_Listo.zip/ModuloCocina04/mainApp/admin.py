from django.contrib import admin
from .models import Mesa, Pedido

@admin.register(Mesa)
class MesaAdmin(admin.ModelAdmin):
    list_display = ('id', 'numero', 'descripcion')
    search_fields = ('numero', 'descripcion')

@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ('id', 'mesa', 'estado', 'creado_en')
    list_filter = ('estado', 'mesa')
    search_fields = ('detalle',)
    autocomplete_fields = ('mesa',)
