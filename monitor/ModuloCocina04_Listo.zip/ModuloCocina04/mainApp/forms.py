from django import forms
from .models import Pedido, Mesa

class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['mesa', 'detalle']
        widgets = {
            'detalle': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Ej: 2 completos, 1 churrasco italiano, sin mayo'}),
        }

class CambiarEstadoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['estado']

class PedidoUpdateForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['mesa', 'detalle', 'estado']
        widgets = {
            'detalle': forms.Textarea(attrs={'rows': 3}),
        }