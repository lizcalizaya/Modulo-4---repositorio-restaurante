from django.db import models

class Mesa(models.Model):
    numero = models.PositiveIntegerField(unique=True, verbose_name='N° Mesa')
    descripcion = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ['numero']

    def __str__(self):
        return f"Mesa {self.numero}"

class Pedido(models.Model):
    ESTADOS = [
        ('PENDIENTE', 'Pendiente'),
        ('EN_PREPARACION', 'En preparación'),
        ('LISTO', 'Listo'),
        ('ENTREGADO', 'Entregado'),
        ('URGENTE', 'Urgente'),
    ]
    mesa = models.ForeignKey(Mesa, on_delete=models.PROTECT, related_name='pedidos')
    detalle = models.TextField(verbose_name='Detalle del pedido')
    estado = models.CharField(max_length=20, choices=ESTADOS, default='PENDIENTE')
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-creado_en']

    def __str__(self):
        return f"Pedido #{self.pk} - Mesa {self.mesa.numero} - {self.estado}"
