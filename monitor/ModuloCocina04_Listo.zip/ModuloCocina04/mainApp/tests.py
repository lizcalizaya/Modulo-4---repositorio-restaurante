from django.test import TestCase
from django.urls import reverse
from .models import Mesa, Pedido

class FlujoBasicoTests(TestCase):
    def setUp(self):
        self.mesa = Mesa.objects.create(numero=1, descripcion='Cerca de la ventana')

    def test_crear_pedido_y_cambiar_estado(self):
        # crear
        resp = self.client.post(reverse('crear_pedido'), {'mesa': self.mesa.id, 'detalle': '1 churrasco'})
        self.assertEqual(resp.status_code, 302)
        p = Pedido.objects.first()
        self.assertEqual(p.estado, 'PENDIENTE')

        # patch-like
        resp2 = self.client.post(reverse('cambiar_estado', args=[p.id]), {'estado': 'EN_PREPARACION'})
        self.assertIn(resp2.status_code, (200, 302))
        p.refresh_from_db()
        self.assertEqual(p.estado, 'EN_PREPARACION')
