from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('pedidos/crear/', views.crear_pedido, name='crear_pedido'),
    path('pedidos/<int:pk>/estado/', views.cambiar_estado, name='cambiar_estado'),
    path('pedidos/estado/', views.pedidos_por_estado, name='pedidos_por_estado'),
    path('pedidos/admin/', views.administrar_pedidos, name='administrar_pedidos'),
    path('pedidos/<int:pk>/editar/', views.editar_pedido, name='editar_pedido'),
    path('pedidos/<int:pk>/eliminar/', views.eliminar_pedido, name='eliminar_pedido'),
    path('cocina/cola', views.cocina_cola, name='cocina_cola'),
    path('cocina/pedidos/<int:pk>', views.cambiar_estado, name='cocina_cambiar_estado'),
]
