from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import render, get_object_or_404, redirect
from django.views.decorators.http import require_http_methods
from .models import Pedido, Mesa
from .forms import PedidoForm, CambiarEstadoForm
from django.db.models import Q, Count
from django.contrib import messages
from .forms import PedidoUpdateForm

def inicio(request):
    pedidos = Pedido.objects.select_related('mesa').all()
    form = PedidoForm()
    context = {'pedidos': pedidos, 'form': form}
    return render(request, 'mainApp/pedidos_list.html', context)

@require_http_methods(['POST'])
def crear_pedido(request):
    form = PedidoForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect('inicio')
    pedidos = Pedido.objects.select_related('mesa').all()
    return render(request, 'mainApp/pedidos_list.html', {'pedidos': pedidos, 'form': form})

@require_http_methods(['POST', 'PATCH'])
def cambiar_estado(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    data = request.POST or request.body.decode('utf-8')
    # Soportar application/x-www-form-urlencoded (POST) y body "estado=EN_PREPARACION" (PATCH)
    if isinstance(data, str) and '=' in data and not request.POST:
        try:
            key, value = data.split('=', 1)
            parsed = {key: value}
        except ValueError:
            return HttpResponseBadRequest('Formato inválido')
    else:
        parsed = request.POST

    form = CambiarEstadoForm(parsed, instance=pedido)
    if form.is_valid():
        form.save()
        if form.is_valid():
            form.save()
        # Notificar si el pedido quedó en LISTO
        if pedido.estado == 'LISTO':
            _notify_modulo3_pedido_listo(pedido)
        ...
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'ok': True, 'estado': pedido.estado})
        return redirect('inicio')
    return HttpResponseBadRequest('Datos inválidos')

def pedidos_por_estado(request):
    estado = request.GET.get('estado')

    # Conteos por estado y total
    counts = Pedido.objects.aggregate(
        total=Count('id'),
        pendientes=Count('id', filter=Q(estado='PENDIENTE')),
        en_preparacion=Count('id', filter=Q(estado='EN_PREPARACION')),
        listos=Count('id', filter=Q(estado='LISTO')),
        entregados=Count('id', filter=Q(estado='ENTREGADO')),
    )

    # Si hay filtro, muestra solo ese estado; si no, muestra todos
    if estado:
        pedidos = Pedido.objects.filter(estado=estado).select_related('mesa').order_by('-creado_en')
    else:
        pedidos = Pedido.objects.select_related('mesa').all().order_by('-creado_en')

    estados = [
        ('PENDIENTE', 'Creado'),
        ('EN_PREPARACION', 'En preparación'),
        ('LISTO', 'Listo'),
        ('ENTREGADO', 'Entregado'),
    ]

    contexto = {
        'pedidos': pedidos,
        'estado_seleccionado': estado,
        'estados': estados,
        'counts': counts,
    }
    return render(request, 'mainApp/pedidos_estado.html', contexto)

def administrar_pedidos(request):
    """
    - Muestra todos los pedidos
    - Permite buscar por ID con ?q=ID
    - Si se encuentra el ID, muestra el pedido encontrado destacado
    """
    q = request.GET.get('q', '').strip()
    pedido_encontrado = None

    if q:
        if q.isdigit():
            pedido_encontrado = Pedido.objects.select_related('mesa').filter(id=int(q)).first()
        else:
            messages.warning(request, 'El ID debe ser numérico.')

    pedidos = Pedido.objects.select_related('mesa').all().order_by('-creado_en')

    return render(request, 'mainApp/pedidos_admin.html', {
        'pedidos': pedidos,
        'pedido_encontrado': pedido_encontrado,
        'q': q
    })


@require_http_methods(['GET', 'POST'])
def editar_pedido(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == 'POST':
        form = PedidoUpdateForm(request.POST, instance=pedido)
        if form.is_valid():
            form.save()
            messages.success(request, f'Pedido #{pedido.id} modificado correctamente.')
            return redirect('administrar_pedidos')
    else:
        form = PedidoUpdateForm(instance=pedido)

    return render(request, 'mainApp/pedido_edit.html', {'form': form, 'pedido': pedido})


@require_http_methods(['POST', 'GET'])
def eliminar_pedido(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == 'POST':
        pedido.delete()
        messages.success(request, f'Pedido #{pk} eliminado.')
        return redirect('administrar_pedidos')

    # Confirmación por GET
    return render(request, 'mainApp/pedido_confirm_delete.html', {'pedido': pedido})

def cocina_cola(request):
    """
    Cola de cocina: pedidos en espera (pendientes), ordenados por fecha de creación.
    Devuelve JSON.
    """
    pendientes = Pedido.objects.filter(estado='PENDIENTE')\
                                .select_related('mesa')\
                                .order_by('creado_en')

    data = [{
        'id': p.id,
        'mesa': p.mesa.numero,
        'detalle': p.detalle,
        'estado': p.estado,
        'creado_en': p.creado_en.isoformat(),
    } for p in pendientes]

    return JsonResponse({'results': data})


def _notify_modulo3_pedido_listo(pedido):
    """
    Envía una notificación al Módulo 3 cuando un pedido está listo.
    Si no hay URL configurada, no hace nada.
    """
    from django.conf import settings
    import json, urllib.request

    url = getattr(settings, 'MODULO3_WEBHOOK_URL', '') or ''
    if not url:
        return  # No está configurado: salimos silenciosamente.

    payload = {
        'pedido_id': pedido.id,
        'estado': pedido.estado,
        'mesa': pedido.mesa.numero,
        'detalle': pedido.detalle,
        'actualizado_en': pedido.actualizado_en.isoformat() if pedido.actualizado_en else None,
    }
    data = json.dumps(payload).encode('utf-8')

    req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
    try:
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        # En producción, registra el error con logging.
        pass